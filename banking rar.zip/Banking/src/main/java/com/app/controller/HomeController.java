package com.app.controller;

import javax.swing.text.html.FormSubmitEvent.MethodType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.app.model.Customer;
import com.app.model.Payee;
import com.app.service.ICustomerService;

@Controller
@RequestMapping("/home")
public class HomeController {
	
	@Autowired
	private ICustomerService service;

	//1. Registration --not fully implemented
	@RequestMapping("/register")
	public String register(Model map) {
		map.addAttribute("customer", new Customer());
		
		return "Register";
	}
	
	
	//2. Registration saving --not fully implemented
	@RequestMapping(value = "/save", method  = RequestMethod.POST)
	public String save(@ModelAttribute Customer customer,Model map) {
		
		map.addAttribute("message", "Saved with id: "+service.saveCustomer(customer));
		return "Register";
	}
	
	
	
	@RequestMapping("/dashboard")
	public String dashBoard() {
		
		return "Dashboard";
	}
	
	
	@RequestMapping("/addpayee")
	public String addPayeePage(Model map) {
		//form backing object
		map.addAttribute("payee", new Payee());
		
		return "AddPayee";
		
	}
	
	
	@RequestMapping("/savepayee")
	public String savePayee(@ModelAttribute Payee payee,Model map) {
		
		if(service.addPayee(payee))
			map.addAttribute("message", "Added benificiary successfully");
		else
			map.addAttribute("message", "error ");
		
		return "Benificiary";
	}
}
