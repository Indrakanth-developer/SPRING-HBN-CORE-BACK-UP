package com.app.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.app.model.Customer;
import com.app.model.Payee;
import com.app.repo.CustomerRepo;
import com.app.service.ICustomerService;

@Service
public class CustomerSerivceImpl implements ICustomerService {
	
	@Autowired
	private CustomerRepo repo;

	@Override
	public Customer showDashBoard() {
		return null;
	}

	@Override
	public Boolean addPayee(Payee payee) {
		
		return false;
	}

	@Override
	@Transactional
	public Integer saveCustomer(Customer customer) {
		return repo.save(customer).getId();
	}

}
