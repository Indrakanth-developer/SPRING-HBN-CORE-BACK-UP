package com.app.service;

import com.app.model.Customer;
import com.app.model.Payee;

public interface ICustomerService {

	
	public Customer showDashBoard();
	public Boolean addPayee(Payee payee);
	public Integer saveCustomer(Customer customer);
	
}
