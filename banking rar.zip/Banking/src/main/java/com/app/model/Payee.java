package com.app.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class Payee {

	@Id
	@GeneratedValue
	private Integer pid;
	private String pname;
	private String pnickname;
	private String accountNumber;
	private String ifsc;
	
	
	
	public Payee() {
		super();
	}
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getPnickname() {
		return pnickname;
	}
	public void setPnickname(String pnickname) {
		this.pnickname = pnickname;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	@Override
	public String toString() {
		return "Payee [pid=" + pid + ", pname=" + pname + ", pnickname=" + pnickname + ", accountNumber="
				+ accountNumber + ", ifsc=" + ifsc + "]";
	}
	
	
	
}
